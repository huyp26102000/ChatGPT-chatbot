import json
import time

import openai
import requests
from flask import Flask, request
from hashlib import sha256
from base64 import urlsafe_b64encode
from datetime import datetime, timedelta
from pymongo import MongoClient
from bson.objectid import ObjectId

appconfig = open("config.json", "r").read()
appconfig = json.loads(appconfig)
openai.api_key = appconfig["gpt_api_key"]

connectionString = "mongodb://localhost:27017/chatbot-gpt"
client = MongoClient(connectionString)

dbs = client.list_database_names()
db = client['Chatbot-chatgpt']
connection = db.list_collection_names()
thread_collection = db['thread']
message_collection = db['messages']

app = Flask(__name__)
question = ['MOTIVATION QUOTE', 'RÚT NGẮN ĐOẠN VĂN', 'TƯ VẤN VÀ TRÒ CHUYỆN']
@app.route("/", methods=['GET'])
def zaloverify():
    print('code_verifier:', appconfig['code_verifier'])
    code_verifier = appconfig['code_verifier']
    code_verifier_bytes = code_verifier.encode('ascii')
    code_challenge_bytes = sha256(code_verifier_bytes).digest()
    code_challenge = urlsafe_b64encode(code_challenge_bytes).decode('ascii').rstrip('=')
    print('code_challenge:', code_challenge)
    return "OK", 200

def get_access_token_from_code(app_id, secret_key, code):
    url = "https://oauth.zaloapp.com/v4/oa/access_token"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "secret_key": secret_key
    }
    data = {
        "app_id": app_id,
        "code": code,
        "grant_type": "authorization_code"
    }

    response = requests.post(url, headers=headers, data=data).json()

    return response

def refresh_access_token(app_id, secret_key, refresh_access_token):
    url = 'https://oauth.zaloapp.com/v4/oa/access_token'
    data = {
        'app_id': app_id,
        'grant_type': 'refresh_token',
        'refresh_token': refresh_access_token
    }
    headers = {
        'secret_key': secret_key,
    }
    response = requests.post(url, headers=headers, data=data)

    if response.ok:
        access_token = response.json()['access_token']
        print('New access token:', access_token)

        # update new access token to config.json
        with open('config.json', 'r') as f:
            data = json.load(f)
        data['access_token'] = access_token
        data['refresh_access_token'] = response.json()['refresh_token']
        with open('config.json', 'w') as f:
            json.dump(data, f)
    else:
        print('Failed to refresh access token:', response.content)

    return response

def get_zalo_access_token():
    with open('config.json', 'r') as f:
        config = json.load(f)

    # Check if access token is still valid
    expires_in = 0
    access_token = config['access_token']
    if access_token:
        token_expiry = datetime.fromtimestamp(float(config['expires_in']))
        expires_in = (token_expiry - datetime.now()).total_seconds()
    if expires_in > 0:
        times = datetime.fromtimestamp(float(expires_in))
        formatted_time = times.strftime("%I:%M %p")
        print("Expiration time: ", formatted_time)
        return access_token

    # Access token is expired, refresh it
    refresh_token = config['refresh_access_token']
    try:
        if refresh_token:
            new_token_response = refresh_access_token(config['app_id'], config['secret_key'], refresh_token)
            if new_token_response.ok:
                new_token_data = new_token_response.json()
                access_token = new_token_data['access_token']
                if access_token:
                    config['access_token'] = access_token
                    config['expires_in'] = str(datetime.now().timestamp() + float(new_token_data['expires_in']))
                    config['refresh_access_token'] = new_token_data['refresh_token']
                    with open('config.json', 'w') as f:
                        json.dump(config, f)
                    return access_token
                else:
                    print('Failed to get access token from refresh token response:', new_token_data)
            else:
                print('Failed to refresh access token:', new_token_response.content)
        else:
            print('No refresh token found in config file.')

    except Exception as ex:
        print("error: ", ex)

    return ''

def get_recent_thread(sender_id):
    now = datetime.now()
    five_minutes_ago = now - timedelta(minutes=5)
    thread = thread_collection.find_one({'sender_id': sender_id, "created_at": {"$gte": five_minutes_ago, "$lte": now}})
    if thread is None:
        # Create a new document if not found
        thread = {'sender_id': sender_id, 'created_at': datetime.now(), 'actions': 'None'}
        thread_collection.insert_one(thread)
        return None
    else:
        return thread

def check_entry_message(message_data):
    message_id = message_data['message']['msg_id']

    message = message_collection.find_one({'message_id': message_id})
    if message is not None:
        return message
    # Create a new document if not found
    new_message = {'message_id': message_id, 'data': message_data}
    message_collection.insert_one(new_message)
    return None
def add_action(sender_id, thread, action):
    if thread is not None:
        now = datetime.now()
        find_thread_sender = thread_collection.find_one({'sender_id': sender_id})
        if find_thread_sender is not None:
            thread['actions'] = action
            thread['created_at'] = now

        thread_collection.replace_one({'_id': thread['_id']}, thread, upsert=True)
def load_buttons(title_button):
    pay_load = {'buttons': []}
    if len(title_button) > 5:
        return 'Không hỗ trợ nhiều hơn 5 button'
    for i in title_button:
        for key, values in i.items():
            pay_load['buttons'] += {
                "title": key,
                "type": "oa.query.show",
                "payload": values
            },
    return pay_load
def options_button(opt):
    button_payload = {'buttons': []}
    if opt == 0:
        button_items = [
            {
                "Kết thúc": "KẾT THÚC"
            },
        ]
        button_payload = load_buttons(button_items)
    elif opt == 1:
        button_items = [
            {
                "Rút ngắn đoạn văn": "RÚT NGẮN ĐOẠN VĂN"
            },
            {
                "Motivation quote": "MOTIVATION QUOTE"
            },
            {
                "TƯ VẤN VÀ TRÒ CHUYỆN": "TƯ VẤN VÀ TRÒ CHUYỆN"
            },
        ]
        button_payload = load_buttons(button_items)
    elif opt == 2:
        button_items = [
            {
                "Chat với GPT": "CHAT VỚI GPT"
            },
            {
                "Chat với tư vấn viên": "CHAT VỚI TƯ VẤN VIÊN"
            },
        ]
        button_payload = load_buttons(button_items)
    elif opt == 3:
        button_items = [
            {
                "Bạn là Phụ Huynh": "PHỤ HUYNH"
            },
            {
                "Bạn là Học Sinh/Sinh Viên": "HỌC SINH/SINH VIÊN"
            },
        ]
        button_payload = load_buttons(button_items)
    return button_payload
def message_gpt(message):
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": message},
        ]
    )
    message = completion['choices'][0]['message']['content']
    return message
def send_messages(access_token, message, message_data, thread, change_action):
    sender_id = message_data['sender']['id']
    data = {
      "recipient": {
        "user_id": sender_id
      },
      "message": {
        "text": message
      }
    }
    headers = {'access_token': access_token}

    response = requests.post('https://openapi.zalo.me/v2.0/oa/message', headers=headers, json=data)

    if response.ok:
        if change_action:
            add_action(sender_id, thread, 'None')
        check_entry_message(message_data)
    else:
        print('Lỗi khi gửi tin nhắn: ', response.content)

    return response
def send_message_with_buttons(access_token, message, message_data, thread, change_action):
    sender_id = message_data['sender']['id']
    opt = 1
    use_gpt = True
    if message == 'Bạn cần thêm gì không?' or message == 'Contact':
        use_gpt = False
    if thread is None:
        pass
    else:
        if thread['actions'] == 'Contact':
            opt = 2
            use_gpt = False
        elif thread['actions'] == 'Open gpt':
            opt = 3
        elif thread['actions'] == 'Student chat' or thread['actions'] == 'Parents chat' or thread['actions'] == 'Close gpt':
            opt = 0
            if thread['actions'] == 'Close gpt':
                use_gpt = False
    button_payload = options_button(opt)
    # if use_gpt:
    #     try:
    #         message = message_gpt(message)
    #     except Exception as e:
    #         print('Error from gpt: ', e)
    print(use_gpt)

    payload = {
        "recipient": {
            "user_id": sender_id
        },
        "message": {
            "text": message,
            "attachment": {
                "type": "template",
                "payload": button_payload
            }
        }
    }

    headers = {
        'access_token': access_token
    }

    response = requests.post('https://openapi.zalo.me/v2.0/oa/message', headers=headers, json=payload)

    if response.ok:
        if change_action and thread is not None:
            add_action(sender_id, thread, 'None')
        check_entry_message(message_data)
    else:
        print('Lỗi khi gửi tin nhắn: ', response.content)
    return response
@app.route("/", methods=['POST'])
def zalowebhook():
    data = request.get_json()
    print(data)
    access_token = get_zalo_access_token()
    opt_action = ['None', 'Short poem', 'Contact', 'Open gpt', 'Close gpt', 'Student chat', 'Parents chat']

    if(data['sender']['id'] == '4356460878800442485'):#check id of Tien Nguyen
        message_local = check_entry_message(data)
        print("duplicated" if message_local is not None else "new")
        try:
            if message_local is None:
                message = data['message']['text']
                sender_id = data['sender']['id']
                print('local none')

                thread = get_recent_thread(sender_id)
                if thread is None:
                    print('thread none')
                    message_question = "Bạn hãy đóng vai đại diện cho trường cao đẳng viễn đông và trả lời câu hỏi: " + message
                    send_message_with_buttons(access_token, message_question, data, thread, True)
                else:
                    print('action: ', thread['actions'])
                    if thread['actions'] == opt_action[1]:
                        message_question = 'Hãy rút gọn đoạn văn sau: ' + message
                        send_message_with_buttons(access_token, message_question, data, thread, True)
                    elif thread['actions'] == opt_action[2]:
                        if message == 'CHAT VỚI GPT':
                            add_action(sender_id, thread, opt_action[3])
                            send_message_with_buttons(access_token, 'Xin chào', data, thread, False)
                        elif message == 'CHAT VỚI TƯ VẤN VIÊN':
                            add_action(sender_id, thread, opt_action[4])
                            send_message_with_buttons(access_token, 'Vui lòng đợi tư vấn viên phản hồi!', data, thread, False)
                    elif thread['actions'] == opt_action[3] or thread['actions'] == opt_action[5] or thread['actions'] == opt_action[6]:
                        if message == 'PHỤ HUYNH':
                            message_question = 'Bạn hãy đóng vai đại diện cho trường cao đẳng viễn đông và chào người phụ huynh muốn nói với bạn một cách lịch sự và thân thiện'
                            add_action(sender_id, thread, opt_action[6])
                            send_message_with_buttons(access_token, message_question, data, thread, False)
                        elif message == 'HỌC SINH/SINH VIÊN':
                            add_action(sender_id, thread, opt_action[5])
                            send_messages(access_token, 'Bắt đầu chat', data, thread, False)
                        elif message == 'KẾT THÚC':
                            add_action(sender_id, thread, 'None')
                            send_message_with_buttons(access_token, 'Bạn cần thêm gì không?', data, thread, False)
                        else:
                            message_question = "Bạn hãy đóng vai đại diện cho trường cao đẳng viễn đông và trả lời câu hỏi: " + message
                            send_message_with_buttons(access_token, message_question, data, thread, False)
                    elif thread['actions'] == opt_action[4]:
                        add_action(sender_id, thread, opt_action[4])
                        if message == 'KẾT THÚC':
                            add_action(sender_id, thread, 'None')
                            send_message_with_buttons(access_token, 'Bạn cần thêm gì không?', data, thread, True)
                        else:
                            send_message_with_buttons(access_token, message, data, thread, False)
                    elif thread['actions'] == 'None':
                        if message == "RÚT NGẮN ĐOẠN VĂN":
                            add_action(sender_id, thread, 'Short poem')
                            send_messages(access_token, 'Vui lòng nhập đoạn văn cần rút gọn', data, thread, False)
                        elif message == "MOTIVATION QUOTE":
                            message_question = "Đưa cho tôi một câu nói truyền cảm hứng cho hôm nay"
                            send_message_with_buttons(access_token, message_question, data, thread, False)
                        elif message == 'TƯ VẤN VÀ TRÒ CHUYỆN':
                            print('tu van nha')
                            add_action(sender_id, thread, 'Contact')
                            send_message_with_buttons(access_token, 'Contact', data, thread, False)
                        else:
                            print('we gone here')
                            message_question = "Bạn hãy đóng vai đại diện cho trường cao đẳng viễn đông và trả lời câu hỏi: " + message
                            send_message_with_buttons(access_token, message_question, data, thread, True)
        except Exception as e:
            print(f"An error occurred: {e}")
            return "Error", 500
    else:
        print(data['sender']['id'])
    return '200 OK HTTPS.', 200

if __name__ == '__main__':
    app.run()
